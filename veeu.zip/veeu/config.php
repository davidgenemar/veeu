<?php
//masukan config token yg terdapat pada link di packet captur
// jangan hapus tanda kutip(" ") 

$access_token = 
"df3dee77-abeb-4bcb-ade5-ef6cda948d0c";

// kamu bisa membuat banyak config untuk beberapa akun.
